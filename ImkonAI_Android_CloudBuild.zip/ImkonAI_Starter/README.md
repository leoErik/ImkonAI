# ImkonAI — Android MVP starter

This starter contains the Flutter app source and a GitHub Actions workflow that can build an Android APK in the cloud.

## Included in this MVP
- Uzbek speech recognition when the Android speech service exposes an `uz` locale.
- Text-to-speech attempt using `uz-UZ` (availability depends on the installed Android TTS engine and voice data).
- Voice commands: `salom`, `yordam`, `vaqt`, `sana` / `bugun`, `to'xta`.
- Accessible labels for the main microphone control.
- Microphone and internet permissions are added by the generated Flutter Android project as needed; verify them before release.

## Build the APK using only a phone
1. Download and unzip this project.
2. Sign in to GitHub in your phone browser and create a new empty repository named `ImkonAI`.
3. Upload the contents of this folder to the repository's `main` branch. Make sure `.github/workflows/build-apk.yml` is included. If your phone's file picker hides dot-folders, use GitHub's web editor to create `.github/workflows/build-apk.yml` and paste its contents from this project.
4. Open the repository's **Actions** tab.
5. Select **Build ImkonAI APK**, choose **Run workflow**, and start it (or let the first upload trigger the workflow).
6. When the run finishes successfully, open the run, find **Artifacts**, and download `imkanai-android-apk`.
7. Extract the downloaded artifact ZIP and install `app-release.apk` on your Android phone. Allow installation from that browser/file manager if Android asks.

## Important
- This is a starter MVP source project, not a prebuilt APK. An APK has not yet been compiled or device-tested.
- GitHub account and internet access are required for cloud building.
- Uzbek speech recognition and Uzbek text-to-speech availability varies by device and installed speech services. The app checks for an Uzbek speech locale and explains when it is unavailable.
- Current command handling is rule-based. Camera scene description, OCR, obstacle alerts, backend, AI model integration, user accounts, privacy controls, and full accessibility testing are not included yet.
- Do not rely on camera obstacle alerts as a substitute for a cane, guide dog, or other established mobility aid.
